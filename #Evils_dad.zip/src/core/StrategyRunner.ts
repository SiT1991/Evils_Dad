// core/StrategyRunner.ts
import type { GlobalState } from "./state/GlobalState";

type StrategyFns = {
  dobet?: () => any;
  round?: (result: any) => any;
  progress?: (result: any) => any;
};

export class StrategyRunner {
  private fns: StrategyFns = {};

  constructor(private state: GlobalState) {}

  loadScript(code: string) {
    const ctx = this.createContext();

    const wrapper = new Function(
      "context",
      `
      with (context) {
        ${code}
        return {
          dobet: typeof dobet === "function" ? dobet : null,
          round: typeof round === "function" ? round : null,
          progress: typeof progress === "function" ? progress : null
        };
      }
    `
    );

    this.fns = wrapper(ctx);
  }

  private createContext() {
    const s = this.state.get();

    return {
      game: s.game.gameId,
      balance: s.stats.balance,
      profit: s.stats.profit,
      wagered: s.stats.wagered,
      winstreak: s.stats.winstreak,
      losestreak: s.stats.losestreak,

      // später: resetseed, resetstats, vault, unvault, log, sleep, etc.
    };
  }

  async runDobet() {
    if (!this.fns.dobet) return null;
    return await this.fns.dobet();
  }

  async runRound(result: any) {
    if (!this.fns.round) return;
    return await this.fns.round(result);
  }

  async runProgress(result: any) {
    if (!this.fns.progress) return;
    return await this.fns.progress(result);
  }

  onStart() {}
  onStop() {}
}
