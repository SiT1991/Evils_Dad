export const log = (...args: any[]) => {
  // später: Log-Level, Remote-Logging etc.
  console.log("[EvilBot]", ...args);
};
