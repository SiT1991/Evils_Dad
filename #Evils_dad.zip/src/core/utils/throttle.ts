export function throttle<T extends (...args: any[]) => void>(
  fn: T,
  interval = 100
): (...args: Parameters<T>) => void {
  let last = 0;
  let trailing: number | undefined;

  return (...args: Parameters<T>) => {
    const now = Date.now();
    const remaining = interval - (now - last);

    if (remaining <= 0) {
      if (trailing) {
        window.clearTimeout(trailing);
        trailing = undefined;
      }
      last = now;
      fn(...args);
    } else if (!trailing) {
      trailing = window.setTimeout(() => {
        last = Date.now();
        trailing = undefined;
        fn(...args);
      }, remaining);
    }
  };
}
