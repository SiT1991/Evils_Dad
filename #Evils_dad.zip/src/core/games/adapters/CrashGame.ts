// core/games/adapters/CrashGame.ts
import { BaseGame } from "../BaseGame";
import type { BetRequest, BetResult, GameDefinition } from "../types";
import { StakeClient } from "../../api/StakeClient";

export class CrashGame extends BaseGame {
  definition: GameDefinition = {
    id: "crash",
    name: "Crash",
    minBet: 0.00000001,
    maxBet: 100000,
    defaultParams: {
      autoCashout: 2.0
    }
  };

  constructor(private api: StakeClient) {
    super();
  }

  async placeBet(request: BetRequest): Promise<BetResult> {
    const { amount, currency, params } = request;

    const res = await this.api.crashBet(
      amount,
      params.autoCashout,
      currency
    );

    const multiplier = res.crashBet.payoutMultiplier;
    const win = multiplier > 1;

    return {
      win,
      payout: win ? amount * multiplier : 0,
      multiplier,
      raw: res
    };
  }
}
