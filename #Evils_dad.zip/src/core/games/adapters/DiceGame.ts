// core/games/adapters/DiceGame.ts
import { BaseGame } from "../BaseGame";
import type { BetRequest, BetResult, GameDefinition } from "../types";
import { StakeClient } from "../../api/StakeClient";

export class DiceGame extends BaseGame {
  definition: GameDefinition = {
    id: "dice",
    name: "Dice",
    minBet: 0.00000001,
    maxBet: 100000,
    defaultParams: {
      chance: 49.5,
      condition: "below"
    }
  };

  constructor(private api: StakeClient) {
    super();
  }

  async placeBet(request: BetRequest): Promise<BetResult> {
    const { amount, currency, params } = request;

    const res = await this.api.diceBet(
      amount,
      params.chance,
      params.condition,
      currency
    );

    const roll = res.diceRoll.state.result;
    const multiplier = res.diceRoll.payoutMultiplier;
    const win = multiplier > 0;

    return {
      win,
      payout: win ? amount * multiplier : 0,
      multiplier,
      raw: res
    };
  }
}
