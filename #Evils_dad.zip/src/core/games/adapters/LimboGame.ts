// core/games/adapters/LimboGame.ts
import { BaseGame } from "../BaseGame";
import type { BetRequest, BetResult, GameDefinition } from "../types";
import { StakeClient } from "../../api/StakeClient";

export class LimboGame extends BaseGame {
  definition: GameDefinition = {
    id: "limbo",
    name: "Limbo",
    minBet: 0.00000001,
    maxBet: 100000,
    defaultParams: {
      target: 2.0
    }
  };

  constructor(private api: StakeClient) {
    super();
  }

  async placeBet(request: BetRequest): Promise<BetResult> {
    const { amount, currency, params } = request;

    const res = await this.api.limboBet(amount, params.target, currency);

    const multiplier = res.limboBet.payoutMultiplier;
    const win = multiplier > 1;

    return {
      win,
      payout: win ? amount * multiplier : 0,
      multiplier,
      raw: res
    };
  }
}
