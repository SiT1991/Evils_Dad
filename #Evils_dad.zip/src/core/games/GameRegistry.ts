// core/games/GameRegistry.ts
import type { GameAdapter } from "./types";

export class GameRegistry {
  private games = new Map<string, GameAdapter>();

  register(game: GameAdapter) {
    this.games.set(game.definition.id, game);
  }

  get(id: string): GameAdapter {
    const game = this.games.get(id);
    if (!game) throw new Error(`Unknown game: ${id}`);
    return game;
  }

  list() {
    return [...this.games.values()].map(g => g.definition);
  }
}

export const gameRegistry = new GameRegistry();
