// core/games/BaseGame.ts
import type { BetRequest, BetResult, GameAdapter, GameDefinition } from "./types";

export abstract class BaseGame implements GameAdapter {
  abstract definition: GameDefinition;

  abstract placeBet(request: BetRequest): Promise<BetResult>;

  protected normalizeResult(
    raw: any,
    win: boolean,
    multiplier: number
  ): BetResult {
    return {
      win,
      payout: win ? request.amount * multiplier : 0,
      multiplier,
      raw
    };
  }
}
