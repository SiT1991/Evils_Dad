// core/games/types.ts

export interface BetRequest {
  amount: number;
  currency: string;
  params: Record<string, any>;
}

export interface BetResult {
  win: boolean;
  payout: number;
  multiplier: number;
  raw: unknown;
}

export interface GameDefinition {
  id: string;
  name: string;
  minBet: number;
  maxBet: number;
  defaultParams: Record<string, any>;
}

export interface GameAdapter {
  definition: GameDefinition;

  placeBet(request: BetRequest): Promise<BetResult>;
}
