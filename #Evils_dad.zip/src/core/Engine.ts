// core/Engine.ts
import type { GlobalState } from "./state/GlobalState";
import type { GameRegistry } from "./games/GameRegistry";
import type { StrategyRunner } from "./StrategyRunner";
import type { TimerManager } from "./timers/timerManager";
import { updateStats, setRunning } from "./state/actions";

export class Engine {
  private loopId: number | null = null;
  private lastResult: any = null;

  constructor(
    private state: GlobalState,
    private games: GameRegistry,
    private strategy: StrategyRunner,
    private timers: TimerManager
  ) {}

  start() {
    if (this.state.get().game.isRunning) return;

    setRunning(this.state, true);
    this.strategy.onStart();
    this.runLoop();
  }

  stop() {
    if (!this.state.get().game.isRunning) return;

    setRunning(this.state, false);
    this.strategy.onStop();
    this.timers.clearAll();

    if (this.loopId) {
      cancelAnimationFrame(this.loopId);
      this.loopId = null;
    }
  }

  private runLoop() {
    const tick = async () => {
      if (!this.state.get().game.isRunning) return;

      try {
        await this.executeStep();
      } catch (err) {
        console.error("[Engine] Error:", err);
        this.stop();
      }

      this.loopId = requestAnimationFrame(tick);
    };

    this.loopId = requestAnimationFrame(tick);
  }

  private async executeStep() {
    const gameId = this.state.get().game.gameId;
    if (!gameId) return;

    const game = this.games.get(gameId);

    // 1. Strategy: dobet() → BetRequest
    const betRequest = await this.strategy.runDobet();
    if (!betRequest) return;

    // 2. Game: placeBet()
    const result = await game.placeBet(betRequest);
    this.lastResult = result;

    // 3. Strategy: round(result)
    await this.strategy.runRound(result);

    // 4. Stats aktualisieren
    this.updateStats(result);

    // 5. Strategy: progress()
    await this.strategy.runProgress(result);
  }

  private updateStats(result: any) {
    const stats = this.state.get().stats;

    const newStats = {
      balance: stats.balance + (result.payout - result.amount),
      profit: stats.profit + (result.payout - result.amount),
      wagered: stats.wagered + result.amount,
      wins: stats.wins + (result.win ? 1 : 0),
      losses: stats.losses + (!result.win ? 1 : 0),
      winstreak: result.win ? stats.winstreak + 1 : 0,
      losestreak: !result.win ? stats.losestreak + 1 : 0
    };

    updateStats(this.state, newStats);
  }
}
