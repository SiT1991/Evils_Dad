export type GameId =
  | "dice"
  | "crash"
  | "limbo"
  | "towers"
  | "mines"
  | "roulette"
  | "hilo"
  | "keno"
  | "plinko"
  | "slots"
  | "blackjack"
  | "baccarat"
  | "wheel";

export interface GameConfig {
  id: GameId;
  name: string;
  minBet: number;
  maxBet: number;
  houseEdge: number;
}
