export interface BotState {
  game: string | null;
  running: boolean;
  balance: number;
  profit: number;
  wagered: number;
  stats: Record<string, any>;
}

export class StateStore {
  private state: BotState = {
    game: null,
    running: false,
    balance: 0,
    profit: 0,
    wagered: 0,
    stats: {}
  };

  private listeners = new Set<(state: BotState) => void>();

  get() {
    return this.state;
  }

  set(partial: Partial<BotState>) {
    this.state = { ...this.state, ...partial };
    this.listeners.forEach((cb) => cb(this.state));
  }

  subscribe(cb: (state: BotState) => void) {
    this.listeners.add(cb);
    cb(this.state);
    return () => this.listeners.delete(cb);
  }
}
