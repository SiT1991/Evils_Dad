import type { BotGame } from "../games/types";
import type { StateStore } from "./StateStore";
import type { TimerManager } from "./TimerManager";

export class GameEngine {
  private currentGame: BotGame | null = null;

  constructor(
    private state: StateStore,
    private timers: TimerManager
  ) {}

  setGame(game: BotGame) {
    this.currentGame = game;
  }

  getGame() {
    return this.currentGame;
  }

  resetStats() {
    // hier kannst du später die Stats aus dem State zurücksetzen
    this.state.set({ profit: 0, wagered: 0, stats: {} });
  }

  // hier später: makeBet, handleResult, etc.
}
