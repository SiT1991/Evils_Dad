export function debounce<T extends (...args: never[]) => void>(
  fn: T,
  delay: number
): T {
  let timeout: number | undefined;

  return function (...args: Parameters<T>) {
    window.clearTimeout(timeout);
    timeout = window.setTimeout(() => fn(...args), delay);
  } as T;
}
