type TimerId = number;

export class TimerManager {
  private timeouts = new Set<TimerId>();
  private intervals = new Set<TimerId>();

  setTimeout(fn: () => void, delay: number): TimerId {
    const id = window.setTimeout(() => {
      this.timeouts.delete(id);
      fn();
    }, delay);
    this.timeouts.add(id);
    return id;
  }

  clearTimeout(id: TimerId) {
    window.clearTimeout(id);
    this.timeouts.delete(id);
  }

  setInterval(fn: () => void, interval: number): TimerId {
    const id = window.setInterval(fn, interval);
    this.intervals.add(id);
    return id;
  }

  clearInterval(id: TimerId) {
    window.clearInterval(id);
    this.intervals.delete(id);
  }

  clearAll() {
    this.timeouts.forEach((id) => window.clearTimeout(id));
    this.intervals.forEach((id) => window.clearInterval(id));
    this.timeouts.clear();
    this.intervals.clear();
  }
}
