import { log } from "./utils/logger";

export interface WebSocketManagerOptions {
  url: string;
  reconnectDelayMs?: number;
  maxReconnectDelayMs?: number;
}

export class WebSocketManager {
  private ws: WebSocket | null = null;
  private opts: Required<WebSocketManagerOptions>;
  private reconnectAttempts = 0;
  private manualClose = false;
  private listeners: {
    message: ((ev: MessageEvent) => void)[];
    open: (() => void)[];
    close: (() => void)[];
    error: ((ev: Event) => void)[];
  } = { message: [], open: [], close: [], error: [] };

  constructor(options: WebSocketManagerOptions) {
    this.opts = {
      reconnectDelayMs: options.reconnectDelayMs ?? 1000,
      maxReconnectDelayMs: options.maxReconnectDelayMs ?? 30000,
      url: options.url
    };
  }

  connect() {
    this.manualClose = false;
    this.createSocket();
  }

  private createSocket() {
    log("WS connect", this.opts.url);
    this.ws = new WebSocket(this.opts.url);

    this.ws.onopen = () => {
      log("WS open");
      this.reconnectAttempts = 0;
      this.listeners.open.forEach((cb) => cb());
    };

    this.ws.onmessage = (ev) => {
      this.listeners.message.forEach((cb) => cb(ev));
    };

    this.ws.onerror = (ev) => {
      log("WS error", ev);
      this.listeners.error.forEach((cb) => cb(ev));
    };

    this.ws.onclose = () => {
      log("WS close");
      this.listeners.close.forEach((cb) => cb());
      if (!this.manualClose) {
        this.scheduleReconnect();
      }
    };
  }

  private scheduleReconnect() {
    this.reconnectAttempts++;
    const base = this.opts.reconnectDelayMs;
    const max = this.opts.maxReconnectDelayMs;
    const delay = Math.min(base * Math.pow(2, this.reconnectAttempts - 1), max);
    log(`WS reconnect in ${delay}ms`);
    setTimeout(() => this.createSocket(), delay);
  }

  send(data: any) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    }
  }

  close() {
    this.manualClose = true;
    if (this.ws) {
      this.ws.close();
    }
  }

  onMessage(cb: (ev: MessageEvent) => void) {
    this.listeners.message.push(cb);
  }

  onOpen(cb: () => void) {
    this.listeners.open.push(cb);
  }

  onClose(cb: () => void) {
    this.listeners.close.push(cb);
  }

  onError(cb: (ev: Event) => void) {
    this.listeners.error.push(cb);
  }
}
