import { StateStore } from "./StateStore";
import { TimerManager } from "./TimerManager";
import { GameEngine } from "./GameEngine";
import { StrategyRunner } from "./StrategyRunner";
import { gamesRegistry } from "../games";
import { log } from "./utils/logger";

export class EvilBot {
  readonly state = new StateStore();
  readonly timers = new TimerManager();
  readonly engine = new GameEngine(this.state, this.timers);
  readonly strategyRunner = new StrategyRunner(this.state, this.engine);

  constructor() {
    log("EvilBot initialized");
  }

  setGame(gameId: string) {
    const game = gamesRegistry[gameId];
    if (!game) {
      throw new Error(`Unknown game: ${gameId}`);
    }
    this.state.set({ game: gameId });
    this.engine.setGame(game);
  }

  loadUserScript(code: string) {
    this.strategyRunner.loadScript(code);
  }

  start() {
    this.state.set({ running: true });
    this.strategyRunner.start();
  }

  stop() {
    this.state.set({ running: false });
    this.strategyRunner.stop();
    this.timers.clearAll();
  }

  resetStats() {
    this.engine.resetStats();
  }
}
