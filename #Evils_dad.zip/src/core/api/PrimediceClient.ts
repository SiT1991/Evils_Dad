// core/api/PrimediceClient.ts
import { HttpClient } from "./HttpClient";

export class PrimediceClient {
  private http: HttpClient;

  constructor(baseUrl: string, token?: string) {
    this.http = new HttpClient({ baseUrl, token });
  }

  setToken(token: string) {
    this.http.setToken(token);
  }

  async roll(amount: number, target: number, condition: "above" | "below") {
    return this.http.request("/api/bets/place", {
      amount,
      target,
      condition
    });
  }
}
