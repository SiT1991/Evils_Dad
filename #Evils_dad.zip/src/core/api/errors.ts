// core/api/errors.ts

export class ApiError extends Error {
  constructor(message: string, public code?: string) {
    super(message);
  }
}

export class NetworkError extends Error {
  constructor(message: string) {
    super(message);
  }
}

export class TimeoutError extends Error {
  constructor() {
    super("Request timed out");
  }
}
