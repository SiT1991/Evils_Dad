// core/api/HttpClient.ts
export interface HttpClientOptions {
  baseUrl: string;
  token?: string;
  timeout?: number;
  retries?: number;
}

export class HttpClient {
  private baseUrl: string;
  private token?: string;
  private timeout: number;
  private retries: number;

  constructor(options: HttpClientOptions) {
    this.baseUrl = options.baseUrl;
    this.token = options.token;
    this.timeout = options.timeout ?? 8000;
    this.retries = options.retries ?? 2;
  }

  setToken(token: string) {
    this.token = token;
  }

  async request<T>(path: string, body?: unknown): Promise<T> {
    const url = `${this.baseUrl}${path}`;

    for (let attempt = 0; attempt <= this.retries; attempt++) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.timeout);

        const res = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(this.token ? { "x-access-token": this.token } : {})
          },
          body: body ? JSON.stringify(body) : undefined,
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }

        const json = await res.json();
        if (json.errors) {
          throw new Error(json.errors[0].message);
        }

        return json.data as T;
      } catch (err) {
        if (attempt === this.retries) throw err;
        await new Promise(r => setTimeout(r, 300 * (attempt + 1)));
      }
    }

    throw new Error("Unreachable");
  }
}
