// core/api/types.ts

export interface DiceRollResponse {
  diceRoll: {
    id: string;
    payoutMultiplier: number;
    state: { result: number };
  };
}

export interface LimboResponse {
  limboBet: {
    id: string;
    payoutMultiplier: number;
    state: { result: number };
  };
}

export interface CrashBetResponse {
  crashBet: {
    id: string;
    payoutMultiplier: number;
  };
}
