// core/api/StakeClient.ts
import { HttpClient } from "./HttpClient";
import { StakeEndpoints } from "./endpoints";
import type { DiceRollResponse, LimboResponse, CrashBetResponse } from "./types";

export class StakeClient {
  private http: HttpClient;

  constructor(baseUrl: string, token?: string) {
    this.http = new HttpClient({ baseUrl, token });
  }

  setToken(token: string) {
    this.http.setToken(token);
  }

  async diceBet(amount: number, target: number, condition: "above" | "below", currency: string) {
    return this.http.request<DiceRollResponse>("/_api/graphql", {
      query: StakeEndpoints.diceRoll,
      variables: { amount, target, condition, currency }
    });
  }

  async limboBet(amount: number, target: number, currency: string) {
    return this.http.request<LimboResponse>("/_api/graphql", {
      query: StakeEndpoints.limboBet,
      variables: { amount, target, currency }
    });
  }

  async crashBet(amount: number, autoCashoutPoint: number, currency: string) {
    return this.http.request<CrashBetResponse>("/_api/graphql", {
      query: StakeEndpoints.crashBet,
      variables: { amount, autoCashoutPoint, currency }
    });
  }
}
