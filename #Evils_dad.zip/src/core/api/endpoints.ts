// core/api/endpoints.ts

export const StakeEndpoints = {
  diceRoll: `
    mutation Roll($amount: Float!, $target: Float!, $condition: CasinoGameDiceConditionEnum!, $currency: CurrencyEnum!) {
      diceRoll(amount: $amount, target: $target, condition: $condition, currency: $currency) {
        id
        payoutMultiplier
        state { result }
      }
    }
  `,

  limboBet: `
    mutation Limbo($amount: Float!, $target: Float!, $currency: CurrencyEnum!) {
      limboBet(amount: $amount, target: $target, currency: $currency) {
        id
        payoutMultiplier
        state { result }
      }
    }
  `,

  crashBet: `
    mutation CrashBet($amount: Float!, $autoCashoutPoint: Float!, $currency: CurrencyEnum!) {
      crashBet(amount: $amount, autoCashoutPoint: $autoCashoutPoint, currency: $currency) {
        id
        payoutMultiplier
      }
    }
  `
};
