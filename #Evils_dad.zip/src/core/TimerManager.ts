type TimerId = number;

export class TimerManager {
  private intervals = new Set<TimerId>();
  private timeouts = new Set<TimerId>();

  setInterval(fn: () => void, ms: number): TimerId {
    const id = window.setInterval(fn, ms);
    this.intervals.add(id);
    return id;
  }

  clearInterval(id: TimerId) {
    window.clearInterval(id);
    this.intervals.delete(id);
  }

  setTimeout(fn: () => void, ms: number): TimerId {
    const id = window.setTimeout(fn, ms);
    this.timeouts.add(id);
    return id;
  }

  clearTimeout(id: TimerId) {
    window.clearTimeout(id);
    this.timeouts.delete(id);
  }

  clearAll() {
    this.intervals.forEach((id) => window.clearInterval(id));
    this.timeouts.forEach((id) => window.clearTimeout(id));
    this.intervals.clear();
    this.timeouts.clear();
  }
}
