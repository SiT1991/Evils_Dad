// core/state/selectors.ts
import type { GlobalState } from "./GlobalState";

export const getCurrentGame = (store: GlobalState) =>
  store.get().game.gameId;

export const isRunning = (store: GlobalState) =>
  store.get().game.isRunning;

export const getBalance = (store: GlobalState) =>
  store.get().stats.balance;

export const getSettings = (store: GlobalState) =>
  store.get().settings;

export const getStats = (store: GlobalState) =>
  store.get().stats;
