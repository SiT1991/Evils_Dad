// core/state/actions.ts
import type { GlobalState } from "./GlobalState";
import type { BotSettings, StatsState } from "./types";

export const setGame = (store: GlobalState, gameId: string) => {
  store.update({
    game: {
      ...store.get().game,
      gameId
    }
  });
};

export const setRunning = (store: GlobalState, running: boolean) => {
  store.update({
    game: {
      ...store.get().game,
      isRunning: running
    }
  });
};

export const updateStats = (store: GlobalState, stats: Partial<StatsState>) => {
  store.update({
    stats: {
      ...store.get().stats,
      ...stats
    }
  });
};

export const updateSettings = (store: GlobalState, settings: Partial<BotSettings>) => {
  store.update({
    settings: {
      ...store.get().settings,
      ...settings
    }
  });
};
