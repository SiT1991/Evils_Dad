import type { RootState } from "../types/state";

type Listener = (state: RootState) => void;

export class Store {
  private state: RootState;
  private listeners = new Set<Listener>();

  constructor(initialState: RootState) {
    this.state = initialState;
  }

  getState(): RootState {
    return this.state;
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  update(partial: Partial<RootState>): void {
    this.state = { ...this.state, ...partial };
    this.listeners.forEach((l) => l(this.state));
  }
}

export const createStore = (initial: RootState) => new Store(initial);
