// core/state/Persistence.ts
import type { RootState } from "./types";

const KEY = "evilbot_state";

export const saveState = (state: RootState) => {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {}
};

export const loadState = (): RootState | null => {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
};
