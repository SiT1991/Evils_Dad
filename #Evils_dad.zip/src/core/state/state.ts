import type { GameId } from "../types/game";

export interface BotSettings {
  baseBet: number;
  maxBet: number;
  stopLoss: number;
  takeProfit: number;
  autoReconnect: boolean;
}

export interface GameState {
  currentGame: GameId | null;
  isRunning: boolean;
  lastResult: unknown;
}

export interface RootState {
  settings: BotSettings;
  game: GameState;
}
