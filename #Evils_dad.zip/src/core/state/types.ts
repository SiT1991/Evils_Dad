// core/state/types.ts

export type Currency = "btc" | "eth" | "ltc" | "doge" | "usdt" | "usdc";

export interface BotSettings {
  baseBet: number;
  maxBet: number;
  stopLoss: number;
  takeProfit: number;
  fastMode: boolean;
  autoReconnect: boolean;
}

export interface GameState {
  gameId: string | null;
  lastResult: unknown;
  isRunning: boolean;
}

export interface StatsState {
  balance: number;
  profit: number;
  wagered: number;
  wins: number;
  losses: number;
  winstreak: number;
  losestreak: number;
}

export interface RootState {
  settings: BotSettings;
  game: GameState;
  stats: StatsState;
  currency: Currency;
}
