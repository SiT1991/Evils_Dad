// core/state/GlobalState.ts
import type { RootState } from "./types";

type Listener = (state: RootState) => void;

export class GlobalState {
  private state: RootState;
  private listeners = new Set<Listener>();

  constructor(initial: RootState) {
    this.state = initial;
  }

  get(): RootState {
    return this.state;
  }

  update(patch: Partial<RootState>) {
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((l) => l(this.state));
  }

  subscribe(listener: Listener) {
    this.listeners.add(listener);
    listener(this.state);
    return () => this.listeners.delete(listener);
  }
}
