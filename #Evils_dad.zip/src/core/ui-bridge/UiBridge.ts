// core/ui-bridge/UiBridge.ts
import type { Engine } from "../Engine";
import type { GlobalState } from "../state/GlobalState";
import type { StrategyRunner } from "../StrategyRunner";
import type { WebSocketClient } from "../transport/WebSocketClient";

import { UiEvents } from "./UiEvents";
import type { UiToCoreMessage, CoreToUiMessage } from "./UiMessageTypes";

export class UiBridge {
  private ui = new UiEvents();

  constructor(
    private engine: Engine,
    private state: GlobalState,
    private strategy: StrategyRunner,
    private ws: WebSocketClient
  ) {
    this.setupStateSync();
    this.setupTransportSync();
    this.setupStrategySync();
  }

  // -----------------------------
  // UI → Core
  // -----------------------------
  handleUiMessage(msg: UiToCoreMessage) {
    switch (msg.type) {
      case "ui:start":
        this.engine.start();
        break;

      case "ui:stop":
        this.engine.stop();
        break;

      case "ui:set-game":
        this.state.update({
          game: { ...this.state.get().game, gameId: msg.gameId }
        });
        break;

      case "ui:update-settings":
        this.state.update({
          settings: { ...this.state.get().settings, ...msg.settings }
        });
        break;

      case "ui:load-script":
        this.strategy.loadScript(msg.code);
        break;
    }
  }

  // -----------------------------
  // Core → UI
  // -----------------------------
  sendToUi(msg: CoreToUiMessage) {
    this.ui.emit(msg.type, msg);
  }

  on(event: string, handler: (msg: CoreToUiMessage) => void) {
    this.ui.on(event, handler);
  }

  // -----------------------------
  // State → UI
  // -----------------------------
  private setupStateSync() {
    this.state.subscribe((state) => {
      this.sendToUi({ type: "core:state", state });
      this.sendToUi({ type: "core:stats", stats: state.stats });
    });
  }

  // -----------------------------
  // Transport → UI
  // -----------------------------
  private setupTransportSync() {
    this.ws.on("crash:round", (payload) => {
      this.sendToUi({ type: "core:game-event", event: { type: "crash", payload } });
    });

    this.ws.on("mines:board", (payload) => {
      this.sendToUi({ type: "core:game-event", event: { type: "mines", payload } });
    });

    this.ws.on("keno:draw", (payload) => {
      this.sendToUi({ type: "core:game-event", event: { type: "keno", payload } });
    });

    // usw. für alle Spiele
  }

  // -----------------------------
  // Strategy → UI
  // -----------------------------
  private setupStrategySync() {
    this.strategy.onLog = (msg: string) => {
      this.sendToUi({ type: "core:log", message: msg });
    };

    this.strategy.onError = (err: string) => {
      this.sendToUi({ type: "core:error", error: err });
    };

    this.strategy.onOutput = (output: any) => {
      this.sendToUi({ type: "core:script-output", output });
    };
  }
}
