// core/ui-bridge/UiEvents.ts

export type UiEventHandler = (payload: any) => void;

export class UiEvents {
  private listeners = new Map<string, Set<UiEventHandler>>();

  on(event: string, handler: UiEventHandler) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(handler);
  }

  off(event: string, handler: UiEventHandler) {
    this.listeners.get(event)?.delete(handler);
  }

  emit(event: string, payload: any) {
    this.listeners.get(event)?.forEach((h) => h(payload));
  }
}
