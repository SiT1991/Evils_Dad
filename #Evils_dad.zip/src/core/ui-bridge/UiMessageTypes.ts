// core/ui-bridge/UiMessageTypes.ts

export type UiToCoreMessage =
  | { type: "ui:start" }
  | { type: "ui:stop" }
  | { type: "ui:set-game"; gameId: string }
  | { type: "ui:update-settings"; settings: Record<string, any> }
  | { type: "ui:load-script"; code: string };

export type CoreToUiMessage =
  | { type: "core:state"; state: any }
  | { type: "core:stats"; stats: any }
  | { type: "core:log"; message: string }
  | { type: "core:error"; error: string }
  | { type: "core:game-event"; event: any }
  | { type: "core:script-output"; output: any };
