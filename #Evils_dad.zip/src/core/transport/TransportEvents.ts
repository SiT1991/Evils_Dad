// core/transport/TransportEvents.ts

export type TransportEvent =
  | CrashEvent
  | LimboEvent
  | DiceEvent
  | MinesEvent
  | KenoEvent
  | PlinkoEvent
  | BlackjackEvent
  | BaccaratEvent
  | WheelEvent
  | GenericEvent;

export interface GenericEvent {
  type: string;
  payload: any;
}

export interface CrashEvent {
  type: "crash:round";
  payload: {
    multiplier: number;
    crashed: boolean;
  };
}

export interface LimboEvent {
  type: "limbo:result";
  payload: {
    multiplier: number;
  };
}

export interface DiceEvent {
  type: "dice:result";
  payload: {
    roll: number;
  };
}

export interface MinesEvent {
  type: "mines:board";
  payload: {
    revealed: number[];
    mines: number[];
  };
}

export interface KenoEvent {
  type: "keno:draw";
  payload: {
    numbers: number[];
  };
}

export interface PlinkoEvent {
  type: "plinko:drop";
  payload: {
    multiplier: number;
  };
}

export interface BlackjackEvent {
  type: "blackjack:round";
  payload: any;
}

export interface BaccaratEvent {
  type: "baccarat:round";
  payload: any;
}

export interface WheelEvent {
  type: "wheel:spin";
  payload: any;
}
