// core/transport/Heartbeat.ts

export class Heartbeat {
  private intervalId: number | null = null;

  constructor(
    private send: (msg: any) => void,
    private intervalMs: number = 15000
  ) {}

  start() {
    if (this.intervalId) return;

    this.intervalId = window.setInterval(() => {
      this.send({ type: "ping" });
    }, this.intervalMs);
  }

  stop() {
    if (!this.intervalId) return;
    clearInterval(this.intervalId);
    this.intervalId = null;
  }
}
