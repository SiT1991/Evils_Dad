import { BotWebSocket, type WebSocketOptions } from "./websocket";

export interface ReconnectOptions {
  maxRetries: number;
  baseDelayMs: number;
}

export class ReconnectingWebSocket {
  private ws: BotWebSocket | null = null;
  private retries = 0;

  constructor(
    private options: WebSocketOptions,
    private reconnectOptions: ReconnectOptions
  ) {}

  start() {
    this.ws = new BotWebSocket({
      ...this.options,
      onOpen: () => {
        this.retries = 0;
        this.options.onOpen?.();
      },
      onClose: (ev) => {
        this.options.onClose?.(ev);
        this.scheduleReconnect();
      },
    });

    this.ws.connect();
  }

  private scheduleReconnect() {
    if (this.retries >= this.reconnectOptions.maxRetries) return;
    const delay =
      this.reconnectOptions.baseDelayMs * Math.pow(2, this.retries++);
    setTimeout(() => this.start(), delay);
  }

  send(payload: unknown) {
    this.ws?.send(payload);
  }

  stop() {
    this.ws?.close();
  }
}
