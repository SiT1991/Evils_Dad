// core/transport/WebSocketClient.ts
import type { TransportEvent } from "./TransportEvents";
import { ReconnectStrategy } from "./ReconnectStrategy";
import { Heartbeat } from "./Heartbeat";

export interface WebSocketClientOptions {
  url: string;
  reconnect?: boolean;
  reconnectOptions?: Partial<ReconnectStrategy>;
}

export class WebSocketClient {
  private ws: WebSocket | null = null;
  private reconnectStrategy: ReconnectStrategy;
  private heartbeat: Heartbeat;

  private listeners = new Map<string, Set<(ev: any) => void>>();

  constructor(private opts: WebSocketClientOptions) {
    this.reconnectStrategy = new ReconnectStrategy({
      baseDelay: opts.reconnectOptions?.baseDelay ?? 500,
      maxDelay: opts.reconnectOptions?.maxDelay ?? 15000,
      maxRetries: opts.reconnectOptions?.maxRetries ?? 10,
      jitter: true
    });

    this.heartbeat = new Heartbeat((msg) => this.send(msg));
  }

  connect() {
    this.ws = new WebSocket(this.opts.url);

    this.ws.onopen = () => {
      this.reconnectStrategy.reset();
      this.heartbeat.start();
      this.emit("open", null);
    };

    this.ws.onmessage = (msg) => {
      try {
        const data = JSON.parse(msg.data) as TransportEvent;
        this.emit(data.type, data.payload);
      } catch (err) {
        console.error("[WS] Invalid message:", msg.data);
      }
    };

    this.ws.onerror = (err) => {
      this.emit("error", err);
    };

    this.ws.onclose = () => {
      this.heartbeat.stop();
      this.emit("close", null);

      if (this.opts.reconnect !== false && this.reconnectStrategy.canRetry()) {
        const delay = this.reconnectStrategy.nextDelay();
        setTimeout(() => this.connect(), delay);
      }
    };
  }

  send(payload: any) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify(payload));
  }

  on(event: string, handler: (ev: any) => void) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(handler);
  }

  off(event: string, handler: (ev: any) => void) {
    this.listeners.get(event)?.delete(handler);
  }

  private emit(event: string, payload: any) {
    this.listeners.get(event)?.forEach((h) => h(payload));
  }

  close() {
    this.heartbeat.stop();
    this.ws?.close();
  }
}
