import type { BotEvent } from "../types/events";

export interface WebSocketOptions {
  url: string;
  onMessage: (event: BotEvent) => void;
  onOpen?: () => void;
  onClose?: (ev: CloseEvent) => void;
  onError?: (ev: Event) => void;
}

export class BotWebSocket {
  private socket: WebSocket | null = null;
  private options: WebSocketOptions;

  constructor(options: WebSocketOptions) {
    this.options = options;
  }

  connect() {
    this.socket = new WebSocket(this.options.url);

    this.socket.onopen = () => this.options.onOpen?.();
    this.socket.onclose = (ev) => this.options.onClose?.(ev);
    this.socket.onerror = (ev) => this.options.onError?.(ev);
    this.socket.onmessage = (msg) => {
      try {
        const data = JSON.parse(msg.data as string) as BotEvent;
        this.options.onMessage(data);
      } catch {
        // optional: logger
      }
    };
  }

  send(payload: unknown) {
    if (!this.socket || this.socket.readyState !== WebSocket.OPEN) return;
    this.socket.send(JSON.stringify(payload));
  }

  close() {
    this.socket?.close();
  }
}
