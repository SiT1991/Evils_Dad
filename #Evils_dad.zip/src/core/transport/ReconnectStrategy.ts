// core/transport/ReconnectStrategy.ts

export interface ReconnectOptions {
  baseDelay: number;
  maxDelay: number;
  maxRetries: number;
  jitter?: boolean;
}

export class ReconnectStrategy {
  private retries = 0;

  constructor(private opts: ReconnectOptions) {}

  nextDelay(): number {
    const { baseDelay, maxDelay, jitter } = this.opts;

    let delay = Math.min(
      baseDelay * Math.pow(2, this.retries),
      maxDelay
    );

    if (jitter) {
      delay = delay * (0.8 + Math.random() * 0.4);
    }

    this.retries++;
    return delay;
  }

  canRetry(): boolean {
    return this.retries < this.opts.maxRetries;
  }

  reset() {
    this.retries = 0;
  }
}
