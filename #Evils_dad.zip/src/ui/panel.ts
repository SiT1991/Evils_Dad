// ui/panel.ts
import { UiBridge } from "../core/ui-bridge/UiBridge";
import { Engine } from "../core/Engine";
import { GlobalState } from "../core/state/GlobalState";
import { StrategyRunner } from "../core/StrategyRunner";
import { WebSocketClient } from "../core/transport/WebSocketClient";
import { TimerManager } from "../core/timers/timerManager";
import { gameRegistry } from "../core/games/GameRegistry";

// UI Components
import "./components/bot-root";
import "./components/bot-header";
import "./components/bot-game-selector";
import "./components/bot-stats";
import "./components/bot-console";
import "./components/bot-settings";

export function initPanel() {
  // -----------------------------
  // 1. State initialisieren
  // -----------------------------
  const state = new GlobalState({
    settings: {
      baseBet: 0.00000001,
      maxBet: 1,
      stopLoss: -1,
      takeProfit: 1,
      fastMode: false,
      autoReconnect: true
    },
    game: {
      gameId: "dice",
      isRunning: false,
      lastResult: null
    },
    stats: {
      balance: 0,
      profit: 0,
      wagered: 0,
      wins: 0,
      losses: 0,
      winstreak: 0,
      losestreak: 0
    },
    currency: "btc"
  });

  // -----------------------------
  // 2. Core‑Module
  // -----------------------------
  const timers = new TimerManager();
  const strategy = new StrategyRunner(state);
  const ws = new WebSocketClient({
    url: "wss://stake.com/_ws/game",
    reconnect: true
  });

  const engine = new Engine(state, gameRegistry, strategy, timers);

  // -----------------------------
  // 3. UI‑Bridge
  // -----------------------------
  const bridge = new UiBridge(engine, state, strategy, ws);

  // -----------------------------
  // 4. Panel in die Seite einfügen
  // -----------------------------
  const root = document.createElement("bot-root") as any;
  root.setBridge(bridge);

  const container = document.createElement("div");
  container.style.position = "fixed";
  container.style.top = "20px";
  container.style.right = "20px";
  container.style.zIndex = "999999";
  container.style.fontFamily = "Inter, sans-serif";

  container.appendChild(root);
  document.body.appendChild(container);

  // -----------------------------
  // 5. UI → Core Events
  // -----------------------------
  container.addEventListener("ui:start", () => bridge.handleUiMessage({ type: "ui:start" }));
  container.addEventListener("ui:stop", () => bridge.handleUiMessage({ type: "ui:stop" }));

  container.addEventListener("ui:set-game", (e: any) =>
    bridge.handleUiMessage({ type: "ui:set-game", gameId: e.detail.gameId })
  );

  container.addEventListener("ui:update-settings", (e: any) =>
    bridge.handleUiMessage({
      type: "ui:update-settings",
      settings: e.detail.settings
    })
  );

  container.addEventListener("ui:load-script", (e: any) =>
    bridge.handleUiMessage({
      type: "ui:load-script",
      code: e.detail.code
    })
  );

  // -----------------------------
  // 6. Core → UI Events
  // -----------------------------
  bridge.on("core:stats", (msg) => {
    root.shadowRoot?.querySelector("bot-stats")?.update(msg.stats);
  });

  bridge.on("core:log", (msg) => {
    root.shadowRoot?.querySelector("bot-console")?.log(msg.message);
  });

  bridge.on("core:error", (msg) => {
    root.shadowRoot?.querySelector("bot-console")?.log("ERROR: " + msg.error);
  });

  bridge.on("core:game-event", (msg) => {
    root.shadowRoot?.querySelector("bot-console")?.log(
      `[EVENT] ${msg.event.type}: ${JSON.stringify(msg.event.payload)}`
    );
  });

  // -----------------------------
  // 7. WebSocket starten
  // -----------------------------
  ws.connect();
}
