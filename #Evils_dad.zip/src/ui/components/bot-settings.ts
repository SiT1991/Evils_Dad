// ui/components/bot-settings.ts
export class BotSettings extends HTMLElement {
  private shadow: ShadowRoot;

  constructor() {
    super();
    this.shadow = this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    this.render();
  }

  private render() {
    this.shadow.innerHTML = `
      <style>
        @import url("/ui/tailwind.css");
      </style>

      <div class="p-3 space-y-2">
        <label class="block text-xs text-slate-400">Base Bet</label>
        <input id="basebet" type="number" class="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs" />

        <label class="block text-xs text-slate-400">Stop Loss</label>
        <input id="stoploss" type="number" class="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs" />

        <label class="block text-xs text-slate-400">Take Profit</label>
        <input id="takeprofit" type="number" class="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs" />

        <button id="save" class="w-full bg-blue-600 hover:bg-blue-500 text-xs py-1 rounded">Save</button>
      </div>
    `;

    this.shadow.querySelector("#save")!.addEventListener("click", () => {
      const basebet = Number((this.shadow.querySelector("#basebet") as HTMLInputElement).value);
      const stoploss = Number((this.shadow.querySelector("#stoploss") as HTMLInputElement).value);
      const takeprofit = Number((this.shadow.querySelector("#takeprofit") as HTMLInputElement).value);

      this.dispatchEvent(
        new CustomEvent("ui:update-settings", {
          detail: { settings: { basebet, stoploss, takeprofit } },
          bubbles: true
        })
      );
    });
  }
}

customElements.define("bot-settings", BotSettings);
