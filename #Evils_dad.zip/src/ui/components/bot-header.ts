// ui/components/bot-header.ts
export class BotHeader extends HTMLElement {
  private shadow: ShadowRoot;

  constructor() {
    super();
    this.shadow = this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    this.render();
  }

  private render() {
    this.shadow.innerHTML = `
      <style>
        @import url("/ui/tailwind.css");
      </style>

      <header class="px-4 py-3 border-b border-slate-700 flex items-center justify-between">
        <span class="font-semibold text-sm">EvilBot Next</span>
        <div class="flex gap-2">
          <button id="start" class="bg-emerald-600 hover:bg-emerald-500 text-xs px-2 py-1 rounded">Start</button>
          <button id="stop" class="bg-rose-600 hover:bg-rose-500 text-xs px-2 py-1 rounded">Stop</button>
        </div>
      </header>
    `;

    this.shadow.querySelector("#start")!.addEventListener("click", () => {
      this.dispatchEvent(new CustomEvent("ui:start", { bubbles: true }));
    });

    this.shadow.querySelector("#stop")!.addEventListener("click", () => {
      this.dispatchEvent(new CustomEvent("ui:stop", { bubbles: true }));
    });
  }
}

customElements.define("bot-header", BotHeader);
