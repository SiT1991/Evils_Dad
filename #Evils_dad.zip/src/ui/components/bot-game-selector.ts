// ui/components/bot-game-selector.ts
import { gameRegistry } from "../../core/games/GameRegistry";

export class BotGameSelector extends HTMLElement {
  private shadow: ShadowRoot;

  constructor() {
    super();
    this.shadow = this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    this.render();
  }

  private render() {
    const games = gameRegistry.list();

    this.shadow.innerHTML = `
      <style>
        @import url("/ui/tailwind.css");
      </style>

      <div class="p-3 border-b border-slate-700">
        <label class="block text-xs mb-1 text-slate-400">Game</label>
        <select id="game" class="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs">
          ${games.map(g => `<option value="${g.id}">${g.name}</option>`).join("")}
        </select>
      </div>
    `;

    this.shadow.querySelector("#game")!.addEventListener("change", (e: any) => {
      this.dispatchEvent(
        new CustomEvent("ui:set-game", {
          detail: { gameId: e.target.value },
          bubbles: true
        })
      );
    });
  }
}

customElements.define("bot-game-selector", BotGameSelector);
