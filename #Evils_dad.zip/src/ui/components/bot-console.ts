// ui/components/bot-console.ts
export class BotConsole extends HTMLElement {
  private shadow: ShadowRoot;

  constructor() {
    super();
    this.shadow = this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    this.render();
  }

  log(message: string) {
    const el = this.shadow.querySelector("#log")!;
    el.innerHTML += `<div class="text-xs text-slate-300">${message}</div>`;
    el.scrollTop = el.scrollHeight;
  }

  private render() {
    this.shadow.innerHTML = `
      <style>
        @import url("/ui/tailwind.css");
      </style>

      <div class="p-3 border-b border-slate-700 h-32 overflow-y-auto" id="log"></div>
    `;
  }
}

customElements.define("bot-console", BotConsole);
