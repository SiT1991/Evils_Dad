// ui/components/bot-root.ts
import { UiBridge } from "../../core/ui-bridge/UiBridge";

export class BotRoot extends HTMLElement {
  private shadow: ShadowRoot;
  private bridge!: UiBridge;

  constructor() {
    super();
    this.shadow = this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    this.render();
  }

  setBridge(bridge: UiBridge) {
    this.bridge = bridge;
  }

  private render() {
    this.shadow.innerHTML = `
      <style>
        @import url("/ui/tailwind.css");
      </style>

      <div class="w-80 bg-slate-900 text-slate-100 rounded-xl shadow-xl border border-slate-700 flex flex-col overflow-hidden">
        <bot-header></bot-header>
        <bot-game-selector></bot-game-selector>
        <bot-stats></bot-stats>
        <bot-console></bot-console>
        <bot-settings></bot-settings>
      </div>
    `;
  }
}

customElements.define("bot-root", BotRoot);
