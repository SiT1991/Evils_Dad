import { StateStore } from "../../core/StateStore";
import { gamesRegistry } from "../../games";
import { log } from "../../core/utils/logger";

const templateHtml = `
  <div class="w-80 bg-slate-900 text-slate-100 rounded-xl shadow-xl border border-slate-700 flex flex-col">
    <header class="px-4 py-3 border-b border-slate-700 flex items-center justify-between">
      <span class="font-semibold text-sm">EvilBot Next</span>
      <span class="text-xs text-slate-400">v1.0.0</span>
    </header>
    <div class="p-4 space-y-3">
      <div>
        <label class="block text-xs mb-1 text-slate-400">Game</label>
        <select id="game-select" class="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs">
          ${Object.values(gamesRegistry)
            .map(
              (g) =>
                `<option value="${g.id}">${g.label}</option>`
            )
            .join("")}
        </select>
      </div>
      <div class="flex gap-2">
        <button id="start-btn" class="flex-1 bg-emerald-600 hover:bg-emerald-500 text-xs py-1 rounded">
          Start
        </button>
        <button id="stop-btn" class="flex-1 bg-rose-600 hover:bg-rose-500 text-xs py-1 rounded">
          Stop
        </button>
      </div>
      <div class="text-xs text-slate-300 space-y-1">
        <div>Balance: <span id="balance">0</span></div>
        <div>Profit: <span id="profit">0</span></div>
        <div>Wagered: <span id="wagered">0</span></div>
      </div>
    </div>
  </div>
`;

export class EvilBotPanel extends HTMLElement {
  private root: ShadowRoot;
  private state: StateStore;

  constructor(state: StateStore) {
    super();
    this.state = state;
    this.root = this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    this.render();
  }

  private render() {
    const wrapper = document.createElement("div");
    wrapper.innerHTML = templateHtml;

    const style = document.createElement("style");
    // Tailwind build output (minified) wird hier injected
    style.textContent = `@import url("https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css");`;

    this.root.innerHTML = "";
    this.root.appendChild(style);
    this.root.appendChild(wrapper);

    const gameSelect = this.root.querySelector<HTMLSelectElement>("#game-select")!;
    const startBtn = this.root.querySelector<HTMLButtonElement>("#start-btn")!;
    const stopBtn = this.root.querySelector<HTMLButtonElement>("#stop-btn")!;
    const balanceEl = this.root.querySelector<HTMLSpanElement>("#balance")!;
    const profitEl = this.root.querySelector<HTMLSpanElement>("#profit")!;
    const wageredEl = this.root.querySelector<HTMLSpanElement>("#wagered")!;

    gameSelect.addEventListener("change", () => {
      const gameId = gameSelect.value;
      this.dispatchEvent(
        new CustomEvent("evilbot:set-game", { detail: { gameId } })
      );
    });

    startBtn.addEventListener("click", () => {
      this.dispatchEvent(new CustomEvent("evilbot:start"));
    });

    stopBtn.addEventListener("click", () => {
      this.dispatchEvent(new CustomEvent("evilbot:stop"));
    });

    this.state.subscribe((s) => {
      balanceEl.textContent = s.balance.toString();
      profitEl.textContent = s.profit.toString();
      wageredEl.textContent = s.wagered.toString();
    });

    log("EvilBotPanel rendered");
  }
}
