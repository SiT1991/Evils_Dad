// ui/components/bot-stats.ts
export class BotStats extends HTMLElement {
  private shadow: ShadowRoot;

  constructor() {
    super();
    this.shadow = this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    this.render();
  }

  update(stats: any) {
    this.shadow.querySelector("#balance")!.textContent = stats.balance.toFixed(8);
    this.shadow.querySelector("#profit")!.textContent = stats.profit.toFixed(8);
    this.shadow.querySelector("#wagered")!.textContent = stats.wagered.toFixed(8);
  }

  private render() {
    this.shadow.innerHTML = `
      <style>
        @import url("/ui/tailwind.css");
      </style>

      <div class="p-3 border-b border-slate-700 text-xs space-y-1">
        <div>Balance: <span id="balance">0</span></div>
        <div>Profit: <span id="profit">0</span></div>
        <div>Wagered: <span id="wagered">0</span></div>
      </div>
    `;
  }
}

customElements.define("bot-stats", BotStats);
