import { EvilBotPanel } from "./components/EvilBotPanel";
import { EvilBot } from "../core/EvilBot";

const bot = new EvilBot();

customElements.define(
  "evilbot-panel",
  class extends EvilBotPanel {
    constructor() {
      super(bot.state);
    }

    connectedCallback() {
      super.connectedCallback();

      this.addEventListener("evilbot:set-game", (e: any) => {
        bot.setGame(e.detail.gameId);
      });

      this.addEventListener("evilbot:start", () => {
        bot.start();
      });

      this.addEventListener("evilbot:stop", () => {
        bot.stop();
      });
    }
  }
);
