// background/background.ts

console.log("[EvilBot] Background worker loaded");

// -----------------------------
// Storage Helpers
// -----------------------------
async function saveState(state: any) {
  await chrome.storage.local.set({ evilbot_state: state });
}

async function loadState() {
  const data = await chrome.storage.local.get("evilbot_state");
  return data.evilbot_state ?? null;
}

// -----------------------------
// Message Routing
// -----------------------------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.type) {
    case "bg:save-state":
      saveState(msg.state).then(() => sendResponse({ ok: true }));
      return true;

    case "bg:load-state":
      loadState().then((state) => sendResponse({ state }));
      return true;

    case "bg:log":
      console.log("[EvilBot]", msg.message);
      sendResponse({ ok: true });
      return;

    default:
      console.warn("[EvilBot] Unknown message:", msg);
      sendResponse({ ok: false });
  }
});

// -----------------------------
// Installation / Update Events
// -----------------------------
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    console.log("[EvilBot] Installed");
  }

  if (details.reason === "update") {
    console.log("[EvilBot] Updated to new version");
  }
});

// -----------------------------
// Optional: Periodic Sync
// -----------------------------
chrome.alarms.create("evilbot-sync", { periodInMinutes: 5 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "evilbot-sync") {
    console.log("[EvilBot] Periodic sync triggered");
  }
});
