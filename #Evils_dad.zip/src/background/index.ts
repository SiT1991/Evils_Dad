chrome.runtime.onInstalled.addListener(() => {
  console.log("[EvilBot] installed");
});

// später: zentrale WS‑Verbindungen, Message‑Passing, Storage‑Sync etc.
