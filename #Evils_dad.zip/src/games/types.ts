export interface BotGame {
  id: string;
  label: string;
  defaultConfig: Record<string, any>;
}
