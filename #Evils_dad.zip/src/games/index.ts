import type { BotGame } from "./types";

export const gamesRegistry: Record<string, BotGame> = {
  limbo: {
    id: "limbo",
    label: "Limbo",
    defaultConfig: {
      game: "limbo",
      target: 2,
      nextbet: 0
    }
  },
  dice: {
    id: "dice",
    label: "Dice",
    defaultConfig: {
      game: "dice",
      chance: 49.5,
      nextbet: 0,
      bethigh: false
    }
  },
  crash: {
    id: "crash",
    label: "Crash",
    defaultConfig: {
      game: "crash",
      target: 2,
      nextbet: 0
    }
  },
  slide: {
    id: "slide",
    label: "Slide",
    defaultConfig: {
      game: "slide",
      nextbet: 0,
      target: 1.5
    }
  },
  blackjack: {
    id: "blackjack",
    label: "Blackjack",
    defaultConfig: {
      game: "blackjack",
      nextbet: 0,
      basebet: 0,
      nextAction: "BLACKJACK_STAND"
    }
  },
  moles: {
    id: "moles",
    label: "Moles",
    defaultConfig: {
      game: "moles",
      nextbet: 0,
      moles: 6,
      picks: [0, 1, 1, 1, 2, 6]
    }
  },
  drill: {
    id: "drill",
    label: "Drill",
    defaultConfig: {
      game: "drill",
      nextbet: 0,
      target: 2,
      pick: 1
    }
  },
  tarot: {
    id: "tarot",
    label: "Tarot",
    defaultConfig: {
      game: "tarot",
      difficulty: "medium",
      nextbet: 0
    }
  },
  chicken: {
    id: "chicken",
    label: "Chicken",
    defaultConfig: {
      game: "chicken",
      steps: 1,
      difficulty: "medium",
      nextbet: 0
    }
  },
  packs: {
    id: "packs",
    label: "Packs",
    defaultConfig: {
      game: "packs",
      nextbet: 0
    }
  },
  bars: {
    id: "bars",
    label: "Bars",
    defaultConfig: {
      game: "bars",
      difficulty: "easy",
      tiles: [2, 3, 4, 5, 6],
      nextbet: 0
    }
  },
  plinko: {
    id: "plinko",
    label: "Plinko",
    defaultConfig: {
      game: "plinko",
      rows: 8,
      risk: "low",
      nextbet: 0
    }
  },
  keno: {
    id: "keno",
    label: "Keno",
    defaultConfig: {
      game: "keno",
      numbers: [1, 2, 3, 4, 5, 6, 7, 8],
      risk: "low",
      nextbet: 0
    }
  },
  mines: {
    id: "mines",
    label: "Mines",
    defaultConfig: {
      game: "mines",
      fields: [1, 2, 3, 4, 5, 6, 7, 8],
      mines: 3,
      nextbet: 0
    }
  },
  wheel: {
    id: "wheel",
    label: "Wheel",
    defaultConfig: {
      game: "wheel",
      nextbet: 0,
      risk: "low",
      segments: 10
    }
  },
  baccarat: {
    id: "baccarat",
    label: "Baccarat",
    defaultConfig: {
      game: "baccarat",
      nextbet: { player: 0, banker: 0.004, tie: 0 }
    }
  },
  dragontower: {
    id: "dragontower",
    label: "Dragon Tower",
    defaultConfig: {
      game: "dragontower",
      nextbet: 0,
      difficulty: "easy",
      eggs: [0, 1]
    }
  },
  roulette: {
    id: "roulette",
    label: "Roulette",
    defaultConfig: {
      game: "roulette",
      chips: [
        { value: "number0", amount: 0.001 },
        { value: "colorBlack", amount: 0.001 }
      ]
    }
  },
  flip: {
    id: "flip",
    label: "Flip",
    defaultConfig: {
      game: "flip",
      nextbet: 0,
      guesses: ["tails", "heads"]
    }
  },
  rps: {
    id: "rps",
    label: "Rock, Paper, Scissors",
    defaultConfig: {
      game: "rps",
      guesses: ["rock", "paper", "scissors"],
      nextbet: 0
    }
  },
  pump: {
    id: "pump",
    label: "Pump",
    defaultConfig: {
      game: "pump",
      difficulty: "easy",
      pumps: 1,
      nextbet: 0
    }
  },
  snakes: {
    id: "snakes",
    label: "Snakes",
    defaultConfig: {
      game: "snakes",
      difficulty: "easy",
      rolls: 1,
      nextbet: 0
    }
  },
  cases: {
    id: "cases",
    label: "Cases",
    defaultConfig: {
      game: "cases",
      difficulty: "easy",
      nextbet: 0
    }
  },
  darts: {
    id: "darts",
    label: "Darts",
    defaultConfig: {
      game: "darts",
      difficulty: "easy",
      nextbet: 0
    }
  },
  diamonds: {
    id: "diamonds",
    label: "Diamonds",
    defaultConfig: {
      game: "diamonds",
      nextbet: 0
    }
  },
  bluesamurai: {
    id: "bluesamurai",
    label: "Blue Samurai",
    defaultConfig: {
      game: "bluesamurai",
      nextbet: 0
    }
  },
  scarabspin: {
    id: "scarabspin",
    label: "Scarab Spin",
    defaultConfig: {
      game: "scarabspin",
      lines: 1,
      nextbet: 0
    }
  },
  tomeoflife: {
    id: "tomeoflife",
    label: "Tome of Life",
    defaultConfig: {
      game: "tomeoflife",
      lines: 1,
      nextbet: 0
    }
  }
};
