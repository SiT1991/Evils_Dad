import "../ui/ui-bootstrap";
import { injectEvilBotPanel } from "./inject-ui";

injectEvilBotPanel();
