// content/inject.ts

// Verhindert doppeltes Laden
if (!window.__EVILBOT_LOADED__) {
  window.__EVILBOT_LOADED__ = true;

  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("ui/panel.js");
  script.type = "module";

  script.onload = () => {
    console.log("[EvilBot] UI Panel injected");
  };

  document.documentElement.appendChild(script);
}
