export function injectEvilBotPanel() {
  if (document.querySelector("evilbot-panel")) return;

  const container = document.createElement("div");
  container.style.position = "fixed";
  container.style.top = "80px";
  container.style.right = "20px";
  container.style.zIndex = "999999";

  const panel = document.createElement("evilbot-panel");
  container.appendChild(panel);
  document.body.appendChild(container);
}
